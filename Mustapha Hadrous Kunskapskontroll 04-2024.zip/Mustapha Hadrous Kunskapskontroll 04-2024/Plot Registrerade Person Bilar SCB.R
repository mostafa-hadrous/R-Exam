library("readxl")
Biler<- read_excel(path ='C:/Users/mosta/OneDrive/Desktop/SCB/registrerade personbilar.xlsx',4)
View(Biler)
plot(Biler$Disel ~ Biler$Year , type = "l" , ylim = c(0, 600000)
     ,ylab = "drivmedel ", xlab = "År",
     main = "Nyregistrerade personbilar efter  drivmedel och Från 2013 Till 2023")


# Plot each line one by one
legend("topright", legend = c("Bensin", "Disel", "El" , "elhybrid"), 
       col = c("red", "blue", "green","black" ), lty = 1)   # Add a legend

lines(Biler$Bensin ~ Biler$Year , type = "b", col = "red" , ylim = c(0, 10000000) ,xlim = c(1, 2025))
lines(Biler$Disel~ Biler$Year, type = "b", col =  "blue" , ylim = c(0, 10000000) ,xlim = c(1, 2025))
lines(Biler$El ~ Biler$Year, type = "b", col = "green" , ylim = c(0, 10000000) ,xlim = c(1, 2025))
lines(Biler$elhybrid ~ Biler$Year, type = "b", col = "black", ylim = c(0, 10000000) ,xlim = c(1, 2025))




