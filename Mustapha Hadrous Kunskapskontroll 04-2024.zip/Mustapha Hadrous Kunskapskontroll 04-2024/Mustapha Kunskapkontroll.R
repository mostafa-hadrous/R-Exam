install.packages("dplyr")
library("readxl")
BMW_Cars<- read_excel(path ='C:/Users/mosta/OneDrive/Desktop/BMW.xlsx')
View(BMW_Cars)

plot(BMW_Cars)
plot(BMW_Cars$Pris , BMW_Cars$Årsmodell)

########     Missing Value    ##########

sum(is.na(BMW_Cars))
BMW_Cars<- na.omit(BMW_Cars) # to remove all observations with missing data on ANY variable in the dataset
str(BMW_Cars)

########    Ploting Tables    ##########

table1 <- table(BMW_Cars$Växellåda)
table1
barplot(table1)
text(c(0.7,1.9),c(220,150),table1,cex = 2, col = 10)

table2<- table(BMW_Cars$Drivmenel)
table2
barplot(table2)
text(c(0.7,1.9,3.1),c(100,300,120),table2,cex = 2, col = 10)


########     Dummy Varibale    ##########

library(dplyr)
colnames(BMW_Cars)
str(BMW_Cars)

BMW_Cars <- BMW_Cars %>% 
  mutate(Drivmenel = case_when(
    Drivmenel == "Bensin" ~ 1,
    Drivmenel == "Hybri" ~ 2,
    Drivmenel == "Diesel" ~ 3,
  ))

BMW_Cars <- BMW_Cars %>% 
  mutate(Växellåda = ifelse(Växellåda == "Manuell", 1, 
                            ifelse(Växellåda == "Automat", 2, NA)))

str(BMW_Cars)

########     Cor    ##########

cor(BMW_Cars$Pris, BMW_Cars$Årsmodell)
cor(BMW_Cars$Pris , BMW_Cars$Miltal)
cor(BMW_Cars$Pris , BMW_Cars$Modell)
cor(BMW_Cars$Årsmodell , BMW_Cars$Miltal)


########      Best Variables for Linear Regression     ##########

###  "backward" ###

full_mdl<-lm(BMW_Cars$Pris~., BMW_Cars) # with all variables 
summary(full_mdl)
bkw<- step(full_mdl, direction = "backward" , trace = 2)
#  forward -  
##(to select best variables for prediction)
# we will start with null model 

null_md1<- lm(BMW_Cars$Pris~1, BMW_Cars)
null_md1
frw<-step(null_md1,scope = list(lower = null_md1,upper = full_mdl) ,direction = "forward" , trace = 3)

#   step wise we will use both (backward and forward)

step_wise<-step(null_md1,
                scope = list(lower = null_md1, upper = full_mdl) ,direction = "both" , trace = 3)

#### select best Variables 

model_1 <- lm(BMW_Cars$Pris ~  Årsmodell + BMW_Cars$Län+ BMW_Cars$Årsmodell
            + Drivmenel  + Miltal+ BMW_Cars$Miltal +
              Växellåda  + BMW_Cars$Modell + BMW_Cars$Modell, BMW_Cars ) # linear model
summary(model_1)
model_1_summary <- summary(model_1)
model_1_summary$adj.r.squared

# The log transformation is often used to reduce skewness of a measurement variable

model_2 <- lm(Pris ~ poly(Årsmodell, 2) + poly(Miltal,2)+ Växellåda  + Drivmenel 
              + BMW_Cars$Län+ Modell, data = BMW_Cars)
summary(model_2)
model_2_summary <- summary(model_2)
model_2_summary$adj.r.squared

             ##### prediction #######

predict_moldel_1<- predict(model_1, BMW_Cars, type = "response"  ) # , type = "response"
predict_moldel_2 <- predict(model_2, BMW_Cars)


library(MASS)  
library(leaps)  
library(Metrics)

# Calculate AIC and BIC
aic_model_1 <- AIC(model_1)
bic_model_1 <- BIC(model_1)
rmse_model_1 <- rmse(BMW_Cars$Pris, predict_moldel_1)
model_1_summary <- summary(model_1)
model_1_summary$adj.r.squared

aic_poly <- AIC(model_2)
bic_poly <- BIC(model_2)
rmse_poly <- rmse(BMW_Cars$Pris, predict_moldel_2)
model_2_summary <- summary(model_2)
model_2_summary$adj.r.squared


# Print AIC and BIC
cat("Linear Regression AIC:", aic_model_1, "\n")
cat("Linear Regression BIC:", bic_model_1, "\n")
cat("Polynomial Regression AIC:", aic_poly, "\n")
cat("Polynomial Regression BIC:", bic_poly, "\n")


results <- data.frame(
  Model = c("Model 1", "Model 2"),
  AIC_data = c(aic_model_1,aic_poly),
  Adj_R_squared = c(model_1_summary$adj.r.squared,model_2_summary$adj.r.squared),
  BIC = c(bic_model_1,bic_poly)
)
results

#### scatter plot 
scatter.smooth(predict_moldel_1~BMW_Cars$Pris,xlab = "Selling price", ylab = "Pred Price", main = "Predict Selling Price")
scatter.smooth(predict_moldel_2~BMW_Cars$Pris,xlab = "Selling price", ylab = "Pred Price", main = "Predict Selling Price")


#### ggplot 

library(ggplot2)
ggplot(data=BMW_Cars, aes(x=predict_moldel_1, y=Pris)) +
  geom_point()+geom_smooth()
# shadow is 95 confidence interval 

ggplot(data=BMW_Cars, aes(x=predict_moldel_2, y=Pris)) +
  geom_point()+geom_smooth()
# shadow is 95 confidence interval 

# Confidence interval for parameters
confint(model_1)

#Interval for the average price
pred<- predict(model_1, BMW_Cars, interval = "confidence")
View(pred)
#Interval for an individuals price
predict(model_1, BMW_Cars, interval = "prediction")

